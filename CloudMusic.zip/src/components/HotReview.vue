<template>
    <div>
        <h1>
            <p>云村热评墙<i class="iconfont icon-iconfontyoujiantou-copy"></i></p>
            <p>JuL</p>
        </h1>
        <h2><p>村友，今日最戳心你评论，你看过几条？</p><span>31</span></h2>
        
    </div>
</template>

<style scoped>
    @import url("http://at.alicdn.com/t/font_1324850_l9q1hm51hbo.css");
      html,body,h1,h2,h3 {
         margin: 0;
         padding: 0;
     }
     div{
         
         background: linear-gradient(90deg,#8c5542,#183c39);
         border-radius: 10px;
        
     }
     div h1{
         display: flex;
         padding: .555556rem .555556rem .277778rem .444444rem;
         width: 100%;
         justify-content: space-between;
         box-sizing: border-box;
         color: #fff;
         font: .407407rem/1 "";
     }
     div p{
         margin: 0;
     }
     div h2{
         color: #ced3ce;
         font:500 .314815rem/1 "";
         display: flex;
         width: 100%;
         justify-content: space-between;
         box-sizing: border-box;
         padding: 0 .694444rem 0 .444444rem;
         align-items: center;
         vertical-align: middle;
         padding-bottom: .388889rem;
     }
     div h2 span{
         color: #fff;
         font:800  20px/1 "";
        
     }
</style>
