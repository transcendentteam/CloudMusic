<template>
    <div>
        <Carousel />
        <MiddleNav />
        <RecList />
        <Newcd />
        <RecMv />

    </div>
</template>

<script>
import Carousel from "@/components/Carousel.vue"
import MiddleNav from "@/components/MiddleNav.vue"
import RecList from "@/components/RecList.vue"
import Newcd from "@/components/Newcd.vue"
import RecMv from "@/components/RecMv.vue"
export default {
    data() {
      return {
        
      }
    },
    computed: {
      
    },
    mounted() {
        
    },
    methods: {
        
    },
    components:{
        Carousel,
        MiddleNav,
        RecList,
        Newcd,
        RecMv
    }
};
</script>

<style scoped>

</style>
