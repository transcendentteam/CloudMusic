<template>
    <div>
        <h1>我是我的页面</h1>
    </div>
</template>

<script>
export default {
};
</script>

<style scoped>

</style>
